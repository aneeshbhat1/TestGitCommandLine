({ 
   init: function(cmp, event, helper) {
      var objectType = cmp.get('v.sobjectType');
      cmp.set('v.sobjectTypeLowerCase', objectType.toLowerCase());
      helper.getRecordHistory(cmp, event, helper);
   }, 
})