({ 
   getRecordHistory: function(cmp, event, helper) {
      this.showSpinner(cmp, event, helper);
      var action = cmp.get('c.getRecordHistory');
      action.setParams({
         "recordId": cmp.get('v.recordId')
      })

      action.setCallback(this, $A.getCallback(function(response) {
         this.hideSpinner(cmp , event, helper);
         var state = response.getState();
         if (state === "SUCCESS") {
            cmp.set('v.recordsList', response.getReturnValue());
            cmp.set('v.recordsCount', response.getReturnValue().length);
         } else if (state === "ERROR") {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
               "mode": "dismissible",
               "title": title,
               "message": message,
               "type": toastType
            })
            toastEvent.fire();
         }

      }));
      $A.enqueueAction(action);
   },

   showSpinner: function (component, event, helper) {
      component.set('v.showSpinner', true);
   },

   hideSpinner: function (component, event, helper) {
      component.set('v.showSpinner', false);

   }, 
})