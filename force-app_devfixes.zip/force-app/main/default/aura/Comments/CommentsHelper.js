// Refactoring by Arjun 22-7-2018
({
    fetchcomments: function(component) {
        var getcomments = component.get('c.getCommentsForRecord');
        debugger;
        getcomments.setParams({ recordID: component.get('v.recordId'), });
        getcomments.setCallback(this, function(res) {
            switch (res.getState()) {
                case 'SUCCESS':
                 var records =res.getReturnValue();
                 debugger;
                                records.forEach(function(record){
                                    console.log(record);
                                });
                       component.set('v.data', res.getReturnValue());
                       component.set('v.MessageCount', res.getReturnValue().length);
                    break;
                case 'INCOMPLETE':
                    break;
                case 'ERROR':
                 var errors = res.getError();
               if (errors) {

               					if (errors[0] && errors[0].message) {
               						var toastEvent = $A.get('e.force:showToast');
               						toastEvent.setParams({
               							title: 'Failure!',
               							type: "error",
               							message: +errors[0].message ,
               							duration:10000
               						});
               						toastEvent.fire();
               						}
               						}
                    break
            }
        });
        $A.enqueueAction(getcomments)
    }
})