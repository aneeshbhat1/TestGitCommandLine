({
   handleEditRecord: function(component, event, helper) {
      helper.editRecord(component);
   },

   handleGoToRecord: function(component, event, helper) {
      helper.goToRecord(component);
   },

   handleDeleteRecord: function(component, event, helper) {
      helper.deleteRecord(component);
   },
})