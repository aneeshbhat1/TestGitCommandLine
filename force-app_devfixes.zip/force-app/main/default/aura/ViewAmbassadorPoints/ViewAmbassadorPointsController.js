({
	handleClick : function(component, event, helper) {
        debugger;
		var urlEvent = $A.get("e.force:navigateToURL");
    urlEvent.setParams({
        "url":"/apex/ViewPoints?id="+component.get("v.recordId")
    });
    urlEvent.fire();

					window.setTimeout(
						$A.getCallback(function() {
							var navEvt = $A.get('e.force:navigateToSObject');
							navEvt.setParams({
								recordId:component.get("v.recordId")
							});
							navEvt.fire();
						}),
						5000
					);
	}
})