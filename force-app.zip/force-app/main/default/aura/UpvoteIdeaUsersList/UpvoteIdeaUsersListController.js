({
    handleRemoveSpinners : function(component, event, helper){
        let loadingSpinner = component.find("loadingSpinner");
        $A.util.addClass(loadingSpinner, 'slds-hide');
    },
})