/**
 * Created by Arkadiusz Celej
 */
({
    queryViews : function(component, event, helper){
        var action = component.get('c.getViews');
        action.setCallback(this, $A.getCallback(function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.views', response.getReturnValue());
                console.log('views',component.get('v.views'));
                helper.wrapViews(component, event, helper);
            } else if (state === "ERROR") {
                var errors = response.getError();
                var message = 'Unknown error';
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "mode": "dismissible",
                    "title": 'Error',
                    "message": message,
                    "type": 'error'
                });
                toastEvent.fire();
            }
        }));
        $A.enqueueAction(action);
    },

    upsertViews : function(component, event, helper){
        var action = component.get('c.saveViews');
        action.setParams({
            views : component.get('v.uploadedViews')
        });
        var self = this;
        action.setCallback(this, $A.getCallback(function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "mode": "dismissible",
                    "title": 'Success',
                    "message": response.getReturnValue(),
                    "type": 'Success'
                });
                toastEvent.fire();
                self.queryViews(component, event, helper);
            } else if (state === "ERROR") {
                var errors = response.getError();
                var message = 'Unknown error';
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "mode": "dismissible",
                    "title": 'Error',
                    "message": message,
                    "type": 'error'
                });
                toastEvent.fire();
            }
        }));
        $A.enqueueAction(action);
    },

    wrapViews : function (component, event, helper) {
        var wrappers = [];
        var m = new Map();
        var views = component.get('v.views');
        for (var i = 0; i < views.length; i++) {
            var view = views[i];
            if(!m.has(view.CRMC_PP__ObjectName__c)){
                m.set(view.CRMC_PP__ObjectName__c, []);
            }
            var vs = m.get(view.CRMC_PP__ObjectName__c);
            view.CRMC_PP__JSON__c = JSON.parse(view.CRMC_PP__JSON__c);
            vs.push({
                view : view,
                isSelected : false,
                formatted : JSON.stringify(view.CRMC_PP__JSON__c, null, 4)
            });
            m.set(view.CRMC_PP__ObjectName__c, vs);
        }
        for(var objName of m.keys()){
            wrappers.push({
                name : objName,
                views : m.get(objName)
            });
        }
        component.set('v.wrappers', wrappers);
    },

    MAX_FILE_SIZE: 750000, /* 1 000 000 * 3/4 to account for base64 */

    importFile : function(component, file) {
        // var fileInput = component.find("files").getElement();
        // var file = fileInput.files[0];
        if (file.size > this.MAX_FILE_SIZE) {
            alert('File size cannot exceed ' + this.MAX_FILE_SIZE + ' bytes.\n' +
                'Selected file size: ' + file.size);
            return;
        }

        var fr = new FileReader();
        var self = this;
        fr.onload = function() {
            var fileContent = fr.result;
            var base64Mark = 'base64,';
            var dataStart = fileContent.indexOf(base64Mark) + base64Mark.length;
            fileContent = fileContent.substring(dataStart);
            self.upload(component, fileContent);
        };

        fr.readAsDataURL(file);
    },

    upload: function(component, fileContent) {
        var loadedViews = component.get('v.loadedViews');
        loadedViews.push({
            formatted : JSON.stringify(JSON.parse(atob(fileContent)), null, 4)
        });
        component.set('v.loadedViews', loadedViews);

        var uploadedViews = component.get('v.uploadedViews');
        var view = JSON.parse(atob(fileContent));
        view.CRMC_PP__JSON__c = JSON.stringify(view.CRMC_PP__JSON__c);
        uploadedViews.push(view);
        component.set('v.uploadedViews', uploadedViews);
    },

    stringify : function (view) {
        var readyToStringify = {};
        var jsonFieldReadyToStringify = {};
        var sortedProps = Object.keys(view.CRMC_PP__JSON__c).sort();
        for (var i = 0; i < sortedProps.length; i++) {
            jsonFieldReadyToStringify[sortedProps[i]] = view.CRMC_PP__JSON__c[sortedProps[i]];
        }
        view.CRMC_PP__JSON__c = jsonFieldReadyToStringify;
        sortedProps = Object.keys(view).sort();
        for (var i = 0; i < sortedProps.length; i++) {
            readyToStringify[sortedProps[i]] = view[sortedProps[i]];
        }

        return JSON.stringify(readyToStringify, null, 4);
    },
    wait : function (ms){
        var start = new Date().getTime();
        var end = start;
        while(end < start + ms) {
            end = new Date().getTime();
        }
    }
})