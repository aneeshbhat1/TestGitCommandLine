({
    handleSuccess : function(component, event, helper) {
        var toastTitle = $A.get("$Label.c.ToastTitleSuccess");
        var toastMessage = $A.get("$Label.c.AccountUpdatedSuccessfully");
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title: toastTitle,
            type: "success",
            message: toastMessage
        });
        toastEvent.fire();
    }, 
})