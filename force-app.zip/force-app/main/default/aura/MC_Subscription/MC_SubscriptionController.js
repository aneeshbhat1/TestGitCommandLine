({
    doInit : function(component, event, helper) {
        var mcSubscriber = {
            isSynchronized : false,
            unSubscribed : false
        };

        var fieldsToQuery = [];
        component.set('v.mcSubscriber', mcSubscriber);
        var recordId = component.get('v.recordId');
        if(recordId && recordId.startsWith('001')) {
            fieldsToQuery.push('PersonContactId');
        }
        fieldsToQuery.push(component.get('v.EmailField'));
        fieldsToQuery.push(component.get('v.EmailOptOutField'));

        component.set('v.fieldsToQuery', fieldsToQuery);
        $A.util.removeClass(component.find('spinner'), 'slds-hide');
    },

    recordUpdated : function (component, event, helper) {
        var eventParams = event.getParams();
        if(eventParams.changeType === "LOADED") {
            component.set('v.subscriberFieldsCopy', component.get('v.subscriberFields'));
            helper.callGetSubscriber(component, event, helper);
        } else if(eventParams.changeType === "CHANGED") {
            var optOutField = component.get('v.EmailOptOutField');
            var oldOptOut = component.get('v.subscriberFieldsCopy')[optOutField];
            var newOptOut = component.get('V.subscriberFields')[optOutField];
            if(oldOptOut != newOptOut){
                $A.util.removeClass(component.find('spinner'), 'slds-hide');
                setTimeout(function(){
                    helper.callGetSubscriber(component, event, helper);
                }, 5000);
            }
        }
    },

    recordIdChanged : function (component, event, helper) {
        if(component.get('v.recordId')){
            component.find('subscriberRecordLoader').reloadRecord();
        }
    }
})