/**
 * Created by Arkadiusz Celej on 08.08.2018.
 */
({
    doInit : function (component, event, helper){
        var fieldsToQuery = [component.get('v.ParentIdField'), component.get('v.EmailField'), component.get('v.EmailOptOutField')];
        component.set('v.fieldsToQuery', fieldsToQuery);
    },

    recordUpdated : function (component, event, helper) {
        var eventParams = event.getParams();
        if(eventParams.changeType === "LOADED" || eventParams.changeType === "CHANGED") {
            var relationName = component.get('v.ParentIdField');
            var parentRecordId = component.get('V.recordFields')[relationName];
            if(parentRecordId){
                $A.createComponent(
                    "c:MC_Subscription",
                    {
                        "aura:id": "subscriber",
                        "recordId": parentRecordId,
                        "EmailField": component.get('v.EmailField'),
                        "EmailOptOutField": component.get('v.EmailOptOutField')
                    },
                    function(newCmp, status, errorMessage){
                        if (status === "SUCCESS") {
                            var body = component.get("v.MC_Subscription");
                            body.push(newCmp);
                            component.set("v.MC_Subscription", body);
                        }
                        else if (status === "ERROR") {
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title: "Could not init MC Subscription Component",
                                message: errorMessage,
                                type: "error"
                            });
                            toastEvent.fire();
                        }
                    }
                );
            }
        }
    }
})