({
    doInit : function(component, event, helper){
        let action = component.get("c.getUsersVotingOnFeedback");
        action.setParams({ recordId : component.get("v.caseId")});
                action.setCallback(this,function(response){
                    let state = response.getState();
                    var toastEvent = $A.get("e.force:showToast");
                    switch (response.getState()) {
                        case "SUCCESS":
                            component.set('v.usersList', response.getReturnValue());
                        case "INCOMPLETE":
                            break;
                        case "ERROR":
                            let errors = response.getError();
                            toastEvent.setParams({
                                "title": "Error",
                                "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                                "type": "error"
                            });
                            toastEvent.fire();
                            break;
                    }
                    var removeSpinners = $A.get("e.c:EventRemoveSpinners");
                    removeSpinners.fire();
                });
                $A.enqueueAction(action);
    },

    clearSpinners : function(component, event, helper){
        let loadingSpinner = component.find("loadingSpinner");
        $A.util.addClass(loadingSpinner, 'slds-hide');
    },
})