({
    doInit : function(component, event, helper){
        let action = component.get("c.getUpvotesForAnFeedback");
        action.setParams({ caseId : component.get("v.recordId")});

        action.setCallback(this,function(response){
            let state = response.getState();
            switch (response.getState()) {

                case "SUCCESS":
                    let currentUserId = $A.get("$SObjectType.CurrentUser.Id");
                    component.set("v.upvoteCounter", response.getReturnValue().length);

                    for(var i = 0; i < response.getReturnValue().length; i++){
                        if(response.getReturnValue()[i].CreatedById.substring(0,15) == currentUserId){
                            component.set("v.currentUserVoted", true);
                            component.set("v.upvoteId", response.getReturnValue()[i].Id);
                            break;
                        }
                    }
                    if(!component.get("v.currentUserVoted")){
                        component.set("v.currentUserVoted", false);
                    }
                case "INCOMPLETE":
                    break;
                case "ERROR":
                    let errors = response.getError();
                    toastEvent.setParams({
                        "title": "Error",
                        "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                        "type": "error"
                    });
                    toastEvent.fire();
                    var removeSpinners = component.get('c.clearSpinners');
                    $A.enqueueAction(removeSpinners);
                    break;
            }
            component.set("v.isLoading", false);

            var removeSpinners = component.get('c.clearSpinners');
            $A.enqueueAction(removeSpinners);
        });
        $A.enqueueAction(action);
    },

    handleClick : function (component, event, helper) {
        let currentUserVoted = component.get('v.currentUserVoted');
        let refreshingSpinner = component.find("refreshingSpinner");
        $A.util.removeClass(refreshingSpinner, 'slds-hide');
            if(currentUserVoted){
                let counter = component.get("v.upvoteCounter");
                component.set("v.upvoteCounter", counter - 1);
                let action = component.get("c.removeUpvote");
                action.setParams({ upvoteId : component.get("v.upvoteId")});
                action.setCallback(this,function(response){
                    let state = response.getState();
                    var toastEvent = $A.get("e.force:showToast");
                    switch (response.getState()) {
                        case "SUCCESS":
                            let initAction = component.get('c.doInit');
                            $A.enqueueAction(initAction);
                        case "INCOMPLETE":
                            break;
                        case "ERROR":
                            let errors = response.getError();
                            toastEvent.setParams({
                                "title": "Error",
                                "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                                "type": "error",
                                "mode": "sticky"
                            });
                            toastEvent.fire();
                            var removeSpinners = component.get('c.clearSpinners');
                            $A.enqueueAction(removeSpinners);
                            break;
                    }
                });
                $A.enqueueAction(action);
            }else{
                let counter = component.get("v.upvoteCounter");
                component.set("v.upvoteCounter", counter + 1);
                let action = component.get("c.createUpvote");
                action.setParams({ caseId : component.get("v.recordId")});
                action.setCallback(this,function(response) {
                    let state = response.getState();
                    var toastEvent = $A.get("e.force:showToast");
                    switch (response.getState()) {
                        case "SUCCESS":
                            let initAction = component.get('c.doInit');
                            $A.enqueueAction(initAction);
                        case "INCOMPLETE":
                            break;
                        case "ERROR":
                            let errors = response.getError();
                            toastEvent.setParams({
                                "title": "Error",
                                "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                                "type": "error",
                                "mode": "sticky"

                            });
                            toastEvent.fire();
                            var removeSpinners = component.get('c.clearSpinners');
                            $A.enqueueAction(removeSpinners);
                            break;
                    }
                });
                $A.enqueueAction(action);
            }
            component.set('v.currentUserVoted', !currentUserVoted);
    },

    handleShowModal: function(component, event, helper) {
        let modalBody;
        $A.createComponent("c:UpvoteIdeaUsers", { caseId : component.get("v.recordId")}, function(content, status){
            if (status === "SUCCESS") {
                modalBody = content;
                component.find('overlayLib').showCustomModal({
                    header: "Upvotes",
                    body: modalBody,
                    showCloseButton: true
                })
            }
        });
    },

    clearSpinners : function(component, event, helper){
        let loadingSpinner = component.find("loadingSpinner");
        let refreshingSpinner = component.find("refreshingSpinner");
        $A.util.addClass(loadingSpinner, 'slds-hide');
        $A.util.addClass(refreshingSpinner, 'slds-hide');
    }
})