// Refactoring by Arjun 22-7-2018
({
    fetchparameters: function(component) {
        var getparameters = component.get('c.getRankDetailsForrecord');
        getparameters.setParams({ recordId: component.get('v.recordId'), });
        getparameters.setCallback(this, function(res) {
            switch (res.getState()) {
                case 'SUCCESS':
                    var str = component.get('v.recordId');
                    var rankingDetails='';
                    component.set("v.Object",res.getReturnValue());
                    if(typeof(component.get("v.Object").RankingDetail__c) != "undefined" && component.get("v.Object").Ranking__c != null)
                    {
                        rankingDetails=component.get("v.Object").RankingDetail__c;
                        component.set("v.rank",component.get("v.Object").Ranking__c);
                         if( ! $A.util.isEmpty(rankingDetails))
                    		{
                        		this.getrankingDeatils(rankingDetails,component);
                    		}
                    }
                    break;
                case 'INCOMPLETE':
                    break;
                case 'ERROR':
                 var errors = res.getError();
               if (errors) {

               					if (errors[0] && errors[0].message) {
               						var toastEvent = $A.get('e.force:showToast');
               						toastEvent.setParams({
               							title: 'Failure!',
               							type: "error",
               							message: +errors[0].message ,
               							duration:10000
               						});
               						toastEvent.fire();
               						}
               						}
                    break
            }
        });
        $A.enqueueAction(getparameters)
    },
    
    getrankingDeatils:function(rankingdetailsString,Component)
    {
        var textvalues=[];
        rankingdetailsString.split('|').forEach(function(element) {
            var arr = element.split(':');
            if(arr.length >0)
            {
              var text=arr[0].trim();
              textvalues.push(' '+text);  
            }
			});
        Component.set("v.rankParameters",textvalues);
        Component.set("v.Count",textvalues.length);
    }
})