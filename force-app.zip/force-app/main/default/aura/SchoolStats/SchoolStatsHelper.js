/**
 * Created by britenet-patrykzak on 17/08/2018.
 */
({
    calculateStats : function(component, bookings, opportunities, leads){

        var stats = component.get('v.stats');
        var statsWrapper = {};
        var currentYear = component.get('v.currentYear');
        var statsAmount = component.get('v.statsAmount');

        if(bookings && bookings.length){
            for(var i = 0; i < bookings.length; i++){
                var bookingYear = bookings[i].BookingStatsYear__c;
                if(currentYear - bookingYear > 4){
                    continue;
                }
                var statsKey = '1_' + bookings[i].Program__c + '_' + bookings[i].Status__c;
                if(statsWrapper[statsKey]){
                    var sw = statsWrapper[statsKey];
                    if(sw.years[currentYear - bookingYear]){
                        sw.years[currentYear - bookingYear]++;
                    } else {
                        sw.years[currentYear - bookingYear] = 1;
                    }
                    sw.yearTotal++;
                } else {
                    var years = [0,0,0,0,0];
                    years[currentYear - bookingYear] = 1;
                    statsWrapper[statsKey] = {
                        program: bookings[i].Program__c,
                        status: bookings[i].Status__c,
                        years: years,
                        yearTotal: 1
                    };
                }
            }
        }
        if(opportunities && opportunities.length){
            for(var i = 0; i < opportunities.length; i++){
                var oppYear = opportunities[i].EnquiryYear__c;
                if(currentYear - oppYear > 4){
                    continue;
                }

                var status;
                if( opportunities[i].StageName == 'To Qualify' ||
                    opportunities[i].StageName == 'To Contact' ||
                    opportunities[i].StageName == 'Follow Up'
                ){
                    status = 'TQ/TC/FU';
                } else {
                    status = 'SC/CL';
                }
                
                var statsKey = '2_' + opportunities[i].Program__c + '_' + status;
                if(statsWrapper[statsKey]){
                    var sw = statsWrapper[statsKey];
                    if(sw.years[currentYear - oppYear]){
                        sw.years[currentYear - oppYear]++;
                    } else {
                        sw.years[currentYear - oppYear] = 1;
                    }
                    sw.yearTotal++;
                } else {
                    var years = [0,0,0,0,0];
                    years[currentYear - oppYear] = 1;
                    statsWrapper[statsKey] = {
                        program: opportunities[i].Program__c,
                        status: status,
                        years: years,
                        yearTotal: 1
                    };
                }
            }
        }
        if(leads && leads.length){
            for(var i = 0; i < leads.length; i++){
                var leadYear = leads[i].EnquiryYear__c;
                if(currentYear - leadYear > 4){
                    continue;
                }
                var statsKey = '3_' + leads[i].Program__c;
                if(statsWrapper[statsKey]){
                    var sw = statsWrapper[statsKey];
                    if(sw.years[currentYear - leadYear]){
                        sw.years[currentYear - leadYear]++;
                    } else {
                        sw.years[currentYear - leadYear] = 1;
                    }
                    sw.yearTotal++;
                } else {
                    var years = [0,0,0,0,0];
                    years[currentYear - leadYear] = 1;
                    statsWrapper[statsKey] = {
                        program: leads[i].Program__c,
                        status: 'Leads',
                        years: years,
                        yearTotal: 1
                    };
                }
            }
        }
        for(var row in statsWrapper){
            if(statsWrapper.hasOwnProperty(row)){
                stats.push(statsWrapper[row]);
                statsAmount += statsWrapper[row].yearTotal;
            }
        }
        component.set('v.stats', stats);
        component.set('v.statsAmount', statsAmount);
    },

    calculateMaxYear : function(component, bookings, opportunities, leads){

        var maxYear = 0;

        if(leads && leads.length){
            for(var i = 0; i < leads.length; i++){
                if(leads[i].EnquiryYear__c > maxYear){
                    maxYear = leads[i].EnquiryYear__c;
                }
            }
        }
        if(bookings && bookings.length){
            for(var i = 0; i < bookings.length; i++){
                if(bookings[i].BookingStatsYear__c > maxYear){
                    maxYear = bookings[i].BookingStatsYear__c;
                }
            }
        }
        if(opportunities && opportunities.length){
            for(var i = 0; i < opportunities.length; i++){
                if(opportunities[i].EnquiryYear__c > maxYear){
                    maxYear = opportunities[i].EnquiryYear__c;
                }
            }
        }
        if(maxYear){
            component.set('v.currentYear', maxYear);
        }
    }
})