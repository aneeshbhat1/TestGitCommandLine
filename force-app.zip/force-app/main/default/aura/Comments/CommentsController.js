({
    init: function (cmp, event, helper) {
        debugger;
        helper.fetchcomments(cmp);
    }
    
})