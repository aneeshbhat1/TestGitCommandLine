({
    navigateToRecord : function(component, event, helper){
        var navEvent = $A.get("e.force:navigateToSObject");
        console.log(component.get("v.row.Id"));
        if(navEvent){
            navEvent.setParams({
                recordId: component.get("v.row.Id"),
            });
            navEvent.fire();
        }
    },

})