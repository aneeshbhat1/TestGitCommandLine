/**
 * Created by thejasvi.a on 6/18/2018.
 */
({
     doInit: function(component, event, helper) {
           helper.getOpportunitiesList(component);
        },

     openRelatedList: function(component, _event){
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
           "relatedListId": "Opportunities__r",
           "parentRecordId": component.get("v.recordId")
        });
        relatedListEvent.fire();
     }
}) 