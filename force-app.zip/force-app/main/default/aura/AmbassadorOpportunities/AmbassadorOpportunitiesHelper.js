/**
 * Created by thejasvi.a on 6/18/2018.
 */
({
     getOpportunitiesList: function(component) {
            var action = component.get('c.getOpportunities');
            action.setParams({
                "accountId": component.get('v.recordId')
            })

            action.setCallback(this, $A.getCallback(function(response) {
             debugger;
                 var state = response.getState();
                 if (state === "SUCCESS") {
                var records =response.getReturnValue();
                records.forEach(function(record){
                    record.linkName = '/'+record.Id;
                });
                component.set('v.data',records);
                    component.set('v.opportunitiesCount', response.getReturnValue().length);
                 }
                 else if (state === "INCOMPLETE") {
                // do something
                }else if (state === "ERROR") {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                           "mode": "dismissible",
                           "title": title,
                           "message": message,
                           "type": toastType
                        })
                        toastEvent.fire();
                    }
                }));
                  $A.enqueueAction(action);
        },
}) 