({
    handleClickCancel: function(component, event, helper){
        $A.get("e.force:closeQuickAction").fire();
    },

    handleClickProceed: function(component, event, helper){

        var record = component.get("v.simpleRecord");
        var currentUserId = $A.get('$SObjectType.CurrentUser.Id');

        if(record.RequestedToDeleteByUser__c != null){
            record.RequestedToDeleteByUser__c = null;
            record.RequestToDeleteDateTime__c = null;
        }else{
            record.RequestedToDeleteByUser__c = currentUserId;
            var now = new Date();
            console.log('FORMAT DATE NOW'+$A.localizationService.formatDate(now, 'yyyy-MM-ddTHH:mm:ss.000+0000'));
            record.RequestToDeleteDateTime__c = $A.localizationService.formatDate(now, 'yyyy-MM-ddTHH:mm:ss.000+0000');
        }
        $A.get("e.force:closeQuickAction").fire();

        component.find("recordData").saveRecord($A.getCallback(function(saveResult){
            var toastEvent =  $A.get("e.force:showToast");
            if(saveResult.state === "SUCCESS" || saveResult.state === "DRAFT"){
                toastEvent.setParams({
                    "mode": "dismissible",
                    "title": $A.get('$Label.c.ToastTitleSuccess'),
                    "message": $A.get('$Label.c.RequestToDeleteActionSuccessMessage'),
                    "type": 'success'
                    });
                    toastEvent.fire();
            }else if(saveResult.state === "INCOMPLETE") {
                toastEvent.setParams({
                    "mode": "dismissible",
                    "title": $A.get('$Label.c.ToastTitleError'),
                    "message": $A.get('$Label.c.RequestToDeleteActionIncompleteMessage'),
                    "type": 'error'
                });
                toastEvent.fire();
            }else if(saveResult.state === "ERROR") {
                var message = $A.get('$Label.c.RequestToDeleteActionErrorMessage') + ' ' + JSON.stringify(saveResult.error);
                toastEvent.setParams({
                    "mode": "dismissible",
                    "title": $A.get('$Label.c.ToastTitleError'),
                    "message": message,
                    "type": 'error'});
                    toastEvent.fire();
            }else{
                var message = 'Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error);
                toastEvent.setParams({
                    "mode": "dismissible",
                    "title": $A.get('$Label.c.ToastTitleError'),
                    "message": message,
                    "type": 'error'
                });
                toastEvent.fire();
            }
        }));
    },
})