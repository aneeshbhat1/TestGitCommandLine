({
   getOpportunitiesList: function(cmp) {

      var action = cmp.get('c.getOpportunities');
      action.setParams({
         "accountId": cmp.get('v.recordId'),
          "lookupName": cmp.get('v.lookupName')
      });

      action.setCallback(this, $A.getCallback(function(response) {
         var state = response.getState();
         if (state === "SUCCESS") {
            cmp.set('v.opportunitiesList', response.getReturnValue());
            cmp.set('v.opportunitiesCount', response.getReturnValue().length);
         } else if (state === "ERROR") {
            var errors = response.getError();
            var message = 'Unknown error';
            if (errors && Array.isArray(errors) && errors.length > 0) {
                message = errors[0].message;
            }
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
               "mode": "dismissible",
               "title": 'Error',
               "message": message,
               "type": 'error'
            });
            toastEvent.fire();
         }
      }));
      $A.enqueueAction(action);
   },

   refreshOpportunitiesRecord: function(component, event) {
      this.getOpportunitiesList(component)
   },
})