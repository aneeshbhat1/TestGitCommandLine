({
	helperMethod : function() {
		//component to be removed
	}
})