({
    doInit:function(component,event,helper){
        //Component to be removed
        
    }
})