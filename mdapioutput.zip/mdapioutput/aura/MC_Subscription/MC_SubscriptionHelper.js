({
    callGetSubscriber : function(component, event, helper) {
        $A.util.removeClass(component.find('spinner'), 'slds-hide');
        var emailField = component.get('v.EmailField');
        var subscriberEmail = component.get('v.subscriberFields')[emailField];
        var action = component.get('c.getSubscriber');
        var recordId = component.get('v.recordId');
        var subscriberKey = recordId && recordId.startsWith('001') ? component.get('v.subscriberFields')['PersonContactId'] : recordId;

        action.setParams({
            emailAddress : subscriberEmail,
            subscriberKey : subscriberKey
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                component.set('v.mcSubscriber', response.getReturnValue());
            }
            else if (state === 'ERROR') {
                var errors = response.getError();
                var toastParams = {
                    title: "Error",
                    message: "Unknown error",
                    type: "error"
                };
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    toastParams.message = errors[0].message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams(toastParams);
                toastEvent.fire();
            }
            $A.util.addClass(component.find('spinner'), 'slds-hide');
        });
        $A.enqueueAction(action);
    }
})