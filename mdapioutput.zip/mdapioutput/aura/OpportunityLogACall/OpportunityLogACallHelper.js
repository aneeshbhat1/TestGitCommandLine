// Refactoring by Shiva 22-1-2018
({
    getFirstContactStatus: function(component) {
        var getFirstContactStatus = component.get('c.isCustomerReached');
        getFirstContactStatus.setParams({ recordId: component.get('v.recordId'), });
        getFirstContactStatus.setCallback(this, function(res) {
            switch (res.getState()) {
                case 'SUCCESS':
                    component.set('v.isCustomerReached', res.getReturnValue());
                    break;
                case 'INCOMPLETE':
                    break;
                case 'ERROR':
                    break
            }
        });
        getFirstContactStatus.setBackground();
        $A.enqueueAction(getFirstContactStatus)
    },
    getCompanyOrSchoolDetails: function(component){      
     var companyOrSchoolDetailsaction = component.get("c.getCompanyOrSchoolDetails");
        companyOrSchoolDetailsaction.setParams({ recordId: component.get("v.recordId") });
        companyOrSchoolDetailsaction.setCallback(this, function(res) {
            switch (res.getState()) {
                case "SUCCESS":
                    //alert('res.getReturnValue()>>>'+JSON.stringify(res.getReturnValue()));                    
                    component.set("v.SelectedLookUpRecord", res.getReturnValue());                  
                    component.set("v.showLookup",true);
                    break;
                case "INCOMPLETE":
                    break;
                case "ERROR":
                    break;
            }
        });
        companyOrSchoolDetailsaction.setBackground();
        $A.enqueueAction(companyOrSchoolDetailsaction);
    },

    navigateToActionScreen: function(component, event) {
        var navigationItemAPI = component.find("navigationItem");
        var workspaceAPI = component.find("workspace");
        var self = this;

        workspaceAPI.isConsoleNavigation().then(function(response) {

            if(response){
                var currentTabId;
                workspaceAPI.getAllTabInfo().then(function(response) {
                    var actionScreen = self.actionScreenPageReference(response);
                    if(actionScreen == null){
                        workspaceAPI.getFocusedTabInfo().then(function(response) {
                            var currentTabId = response.tabId;
                            if(response.isSubtab){
                                currentTabId = response.parentTabId;
                            }else{
                                currentTabId = response.tabId;
                            }
                            workspaceAPI.closeTab({tabId: currentTabId}).then(function(response){
                                workspaceAPI.openTab({
                                    url: '/lightning/n/AG_Action_Screen?overrideNavRules=true',
                                    focus : true
                                });
                            });
                        });
                    }else{
                        workspaceAPI.getFocusedTabInfo().then(function(response) {
                            var currentTabId = response.tabId;
                            if(response.isSubtab){
                                currentTabId = response.parentTabId;
                            }else{
                                currentTabId = response.tabId;
                            }
                            workspaceAPI.openTab({
                                pageReference : actionScreen,
                                focus : true
                            }).then(function(response){
                                workspaceAPI.closeTab({tabId: currentTabId}).then(function(response){
                                    workspaceAPI.getFocusedTabInfo().then(function(response){
                                        var focusedTabId = response.tabId;
                                        workspaceAPI.refreshTab({
                                            tabId: focusedTabId,
                                            includeAllSubtabs: true
                                        });
                                    });
                                });
                            })
                            ;
                        });
                    }
                });
            }else{
                var urlEvent = $A.get("e.force:navigateToURL");
                var LAC_ActionScreenURL = $A.get("$Label.c.LAC_ActionScreenURL");
                urlEvent.setParams({ url: LAC_ActionScreenURL });
                urlEvent.fire();
            }
        })
        .catch(function(error) {
            console.log(error);
        });
    },

    actionScreenPageReference: function(tabSet){
        console.log('isActionScreenAlreadyOpen finished');
        var actionScreenAlreadyOpenFlag;
        var actionScreenPageReference;
        tabSet.forEach(function(element) {
            if(Object.keys(element.pageReference.attributes).indexOf('apiName') != -1 &&
                element.pageReference.attributes.apiName == 'AG_Action_Screen'){
                    actionScreenAlreadyOpenFlag = true;
                    actionScreenPageReference= element.pageReference;
            }
        });
        return actionScreenPageReference;
    },
    
    setPicklistValues:function(component, data){
        var LAC_SELECTED_CLOSEREASON = $A.get("$Label.c.LAC_SELECTED_CLOSEREASON");
        component.set("v.salesAction", JSON.parse(data.salesActions));
        component.set("v.whoIsPaying", JSON.parse(data.whoIsPayingOptions));
        component.set("v.conditions", data.conditions);
        component.set("v.likelihoodToBook", JSON.parse(data.likelihoodToBookOptions));
        component.set("v.hearAboutEF", JSON.parse(data.hearAboutEFOptions));
        component.set("v.destinations", data.destinations);
        component.set("v.durations", data.durations);
        var closeReasonTemp = [];
        var closeReasons = JSON.parse(data.closeReasons);
        component.set("v.closeReasons", closeReasons);
        if (closeReasons instanceof Array) {
            for (var i = 0; i < closeReasons.length; i++) { closeReasonTemp.push(closeReasons[i].toUpperCase()); }
            var closeReasonIndexValue = closeReasonTemp.indexOf(LAC_SELECTED_CLOSEREASON.toUpperCase());
            if (closeReasonIndexValue > 0 && LAC_SELECTED_CLOSEREASON != (null && undefined)) {
                component.set("v.selectedCloseReasonDefault", closeReasons[closeReasonIndexValue]);
            }
        }
        component.set("v.subActions", JSON.parse(data.subActions));
        component.set("v.programs", data.programsForChange); 
        let loaderComp = component.find("loaderComp");
		$A.util.removeClass(loaderComp, "customLoaderTrue");
        
    }, 
    setDefaultDate : function(component){
        var currentYear = new Date().getFullYear();
        component.set("v.DateTimeTemp", moment(new Date(), "DD-MM-YYYY").add(1, "days").format());
        var years = []; 
        years.push(currentYear.toString());
        for (var year = 0; year < 2; year++) {
            years.push((++currentYear).toString());
        }
        component.set("v.years", years);
    },
    populateComponentData :function(component){
        console.log('populateComponentData');
        var LAC_Select = $A.get("$Label.c.LAC_Select");
        component.set("v.selectedCallResult", LAC_Select);
        component.set("v.selectedActionType", LAC_Select);
        var initialDataRetrieveAction = component.get("c.getInitialData");
        initialDataRetrieveAction.setParams(
            { 
                recordId: component.get("v.recordId"),
                program: "" 
            });
        initialDataRetrieveAction.setCallback(this, function(res) {
            switch (res.getState()) {
                case "SUCCESS":        
                    var initialData = JSON.parse(res.getReturnValue());
                    var data = initialData.logACallData;
                    this.setPicklistValues(component, initialData);
                    this.setDefaultData(component,JSON.parse(data));
                    break;
                case "INCOMPLETE":
                    break;
                case "ERROR":
                    break;
            }
        });
        $A.enqueueAction(initialDataRetrieveAction);
        
    },
    setDefaultData : function(component,data){
        if (data != null) {
            if (data.Program == "MULTI") {
                component.set("v.multi", true);
            } else {
                component.set("v.multi", false);
            }
            component.set("v.selectedLikelihoodToBook", data.LikelihoodToBook);
            component.set("v.hearAboutEFValue", data.HearAboutUs);
            component.set("v.destinationsSelected", data.Destinations);
            component.set("v.durationsSelected", data.Duration);
            component.set("v.yearSelected", data.WhenYear);
            component.set("v.monthSelected", data.WhenMonth);
            component.set("v.bookOnDate", data.CloseDate);
            component.set("v.isActiveUser", data.IsActive);
            component.set("v.doNotCall", data.DoNotCall);
            component.set("v.DateTimeTemp", moment(new Date(), "DD-MM-YYYY").add(1, "days").format());
            component.set("v.selectedActionDate", component.get("v.DateTimeTemp"));
            component.set("v.selectedWhoIsPaying", data.WhoIsPayingge);
            component.set("v.oppStageName", data.StageName);
            var phoneNumberCounter = 0;
            if (data.OtherPhone) {
                phoneNumberCounter++;
                component.set("v.displayOtherPhone", "Other" + ": " + data.OtherPhone);
                var initialCommunication = [data.OtherPhone];
                component.set("v.selectedDisplayNumber", initialCommunication);
            }
            if (data.Phone) {
                phoneNumberCounter++;
                component.set("v.displayPhone", "Home" + ": " + data.Phone);
                var initialCommunication = [data.Phone];
                component.set("v.selectedDisplayNumber", initialCommunication);
            }
            if (data.MobilePhone) {
                phoneNumberCounter++;
                component.set("v.displayMobilePhone", "Mobile" + ": " + data.MobilePhone);
                var initialCommunication = [data.MobilePhone];
                component.set("v.selectedDisplayNumber", initialCommunication);
            }
            if(data.Age>=24){
                component.set("v.validAge",true);  
            }
            component.set("v.phoneNumberCounter", phoneNumberCounter);
        } else {
            
            console.log("Commented for some reasons");
        }
        let loaderComp = component.find("loaderComp");
		$A.util.removeClass(loaderComp, "customLoaderTrue");
    }
})