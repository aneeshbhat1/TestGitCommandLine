// Refactoring by Shiva 22-1-2018
({
    getFirstContactStatus: function(component) {
        var getFirstContactStatus = component.get('c.isCustomerReached');
        getFirstContactStatus.setParams({ recordId: component.get('v.recordId'), });
        getFirstContactStatus.setCallback(this, function(res) {
            switch (res.getState()) {
                case 'SUCCESS':
                    component.set('v.isCustomerReached', res.getReturnValue());
                    break;
                case 'INCOMPLETE':
                    break;
                case 'ERROR':
                    break
            }
        });
        $A.enqueueAction(getFirstContactStatus)
    },
    getCompanyOrSchoolDetails: function(component){      
     var companyOrSchoolDetailsaction = component.get("c.getCompanyOrSchoolDetails");
        companyOrSchoolDetailsaction.setParams({ recordId: component.get("v.recordId") });
        companyOrSchoolDetailsaction.setCallback(this, function(res) {
            switch (res.getState()) {
                case "SUCCESS":
                    //alert('res.getReturnValue()>>>'+JSON.stringify(res.getReturnValue()));                    
                    component.set("v.SelectedLookUpRecord", res.getReturnValue());                  
                    component.set("v.showLookup",true);
                    break;
                case "INCOMPLETE":
                    break;
                case "ERROR":
                    break;
            }
        });
        $A.enqueueAction(companyOrSchoolDetailsaction);
    },

    navigateToActionScreen: function(component, event) {
        var navigationItemAPI = component.find("navigationItem");
        var workspaceAPI = component.find("workspace");
        var self = this;

        workspaceAPI.isConsoleNavigation().then(function(response) {

            if(response){
                var currentTabId;
                workspaceAPI.getAllTabInfo().then(function(response) {
                    var actionScreen = self.actionScreenPageReference(response);
                    if(actionScreen == null){
                        workspaceAPI.getFocusedTabInfo().then(function(response) {
                            var currentTabId = response.tabId;
                            if(response.isSubtab){
                                currentTabId = response.parentTabId;
                            }else{
                                currentTabId = response.tabId;
                            }
                            workspaceAPI.closeTab({tabId: currentTabId}).then(function(response){
                                workspaceAPI.openTab({
                                    url: '/lightning/n/AG_Action_Screen?overrideNavRules=true',
                                    focus : true
                                });
                            });
                        });
                    }else{
                        workspaceAPI.getFocusedTabInfo().then(function(response) {
                            var currentTabId = response.tabId;
                            if(response.isSubtab){
                                currentTabId = response.parentTabId;
                            }else{
                                currentTabId = response.tabId;
                            }
                            workspaceAPI.openTab({
                                pageReference : actionScreen,
                                focus : true
                            }).then(function(response){
                                workspaceAPI.closeTab({tabId: currentTabId}).then(function(response){
                                    workspaceAPI.getFocusedTabInfo().then(function(response){
                                        var focusedTabId = response.tabId;
                                        workspaceAPI.refreshTab({
                                            tabId: focusedTabId,
                                            includeAllSubtabs: true
                                        });
                                    });
                                });
                            })
                            ;
                        });
                    }
                });
            }else{
                var urlEvent = $A.get("e.force:navigateToURL");
                var LAC_ActionScreenURL = $A.get("$Label.c.LAC_ActionScreenURL");
                urlEvent.setParams({ url: LAC_ActionScreenURL });
                urlEvent.fire();
            }
        })
        .catch(function(error) {
            console.log(error);
        });
    },

    actionScreenPageReference: function(tabSet){
        console.log('isActionScreenAlreadyOpen finished');
        var actionScreenAlreadyOpenFlag;
        var actionScreenPageReference;
        tabSet.forEach(function(element) {
            if(Object.keys(element.pageReference.attributes).indexOf('apiName') != -1 &&
                element.pageReference.attributes.apiName == 'AG_Action_Screen'){
                    actionScreenAlreadyOpenFlag = true;
                    actionScreenPageReference= element.pageReference;
            }
        });
        return actionScreenPageReference;
    },
})