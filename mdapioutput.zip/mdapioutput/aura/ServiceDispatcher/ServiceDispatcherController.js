({
    callService: function(component, event, helper) {
        let args = event.getParams().arguments;
        return helper.callService(component, args);
    }, 

    getServerCallServiceHandler: function(component, event, helper) {
        return helper.getService(component, {serviceName:'serverActionService'});
    },

    getMessageServiceHandler: function(component, event, helper) {
        return helper.getService(component, {serviceName:'messageService'});
    },

    getUIServiceHandler: function(component, event, helper) {
        return helper.getService(component, {serviceName:'uiService'});
    },

    getNavigationServiceHandler: function(component, event, helper) {
        return helper.getService(component, {serviceName:'navigationService'});
    }
})