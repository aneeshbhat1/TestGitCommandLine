/**
 * Created by britenet-patrykzak on 19/11/2018.
 */
({
    doInit : function(component, event, helper) {
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        component.set('v.UserId', userId);
    },

    login: function(component, event, helper){
        helper.impersonateLogin(component, event);
    },

    resend: function(component, event, helper){
        helper.resendEmail(component, event);
    },
})