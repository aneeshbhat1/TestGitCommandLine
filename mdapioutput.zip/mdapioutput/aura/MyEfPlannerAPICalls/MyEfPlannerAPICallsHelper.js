/**
 * Created by britenet-patrykzak on 19/11/2018.
 */
({
    impersonateLogin : function(component, event, helper) {
        var serviceDispatcher = component.find('serviceDispatcher');
        serviceDispatcher.getUIService().showSpinner();
        var action = component.get('c.getUrlForSalesUser');
        serviceDispatcher.getServerActionService().callServerPromise(
            action,
            {SalesUserId : component.get('v.UserId'), SFAccountId : component.get('v.Opportunity.AccountId')}
        )
        .then($A.getCallback(response => {
            if(response.status == 'Success'){
                serviceDispatcher.getNavigationService().openInNewTab([response.result]);
            } else {
                serviceDispatcher.getMessageService().showWarning(null, response.message);
            }
            serviceDispatcher.getUIService().hideSpinner();
        }))
        .catch($A.getCallback(errors => {
            serviceDispatcher.getMessageService().handleServerErrors(errors);
            serviceDispatcher.getUIService().hideSpinner();
        }));
    },

    resendEmail : function(component, event, helper) {
        var serviceDispatcher = component.find('serviceDispatcher');
        serviceDispatcher.getUIService().showSpinner();
        var action = component.get('c.resendEmailToUser');
        serviceDispatcher.getServerActionService().callServerPromise(
            action,
            {SalesUserId: component.get('v.UserId'), SFAccountId: component.get('v.Opportunity.AccountId')}
        )
        .then($A.getCallback(response => {
            if(response.status == 'Success'){
                serviceDispatcher.getMessageService().showSuccess();
            } else {
                serviceDispatcher.getMessageService().showWarning(null, response.message);
            }
            serviceDispatcher.getUIService().hideSpinner();
        }))
        .catch($A.getCallback(errors => {
            serviceDispatcher.getMessageService().handleServerErrors(errors);
            serviceDispatcher.getUIService().hideSpinner();
        }));
    },
})