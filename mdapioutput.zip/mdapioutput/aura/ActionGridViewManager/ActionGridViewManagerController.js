/**
 * Created by Arkadiusz Celej
 */
({
    init : function (component, event, helper) {
        helper.queryViews(component, event, helper);
    },
    
    export : function (component, event, helper) {
        var wrappers = component.get('v.wrappers');
        var counter = 0;
        for (var i = 0; i < wrappers.length; i++) {
            for (var j = 0; j < wrappers[i].views.length; j++) {
                if(wrappers[i].views[j].isSelected){
                    wrappers[i].views[j].isSelected = false;
                    var view = wrappers[i].views[j];
                    var link = document.createElement("a");
                    link.href = "data:text/csv;base64," + btoa(helper.stringify(view.view));
                    link.download = wrappers[i].name+'.'+view.view.Name+ ".json";

                    counter++;
                    if(counter % 8 == 0){
                        console.log('waiting');
                        helper.wait(1000);
                    }
                    link.click();
                }
            }
        }

        component.set('v.wrappers', wrappers);
    },

    viewSelect : function (component, event, helper) {
        var selected = event.getSource().get('v.text');
        var isSelected = event.getSource().get('v.value');
        var wrappers = component.get('v.wrappers');
        var objName = selected.split('-')[0];
        var viewId = selected.split('-')[1];
        for (var i = 0; i < wrappers.length; i++) {
            if(wrappers[i].name === objName) {
                for (var j = 0; j < wrappers[i].views.length; j++) {
                    if (wrappers[i].views[j].view.Id === viewId) {
                        wrappers[i].views[j].isSelected = isSelected;
                        component.set('v.wrappers', wrappers);
                        break;
                    }
                }
                break;
            }
        }
    },

    objectSelect : function (component, event, helper) {
        var selected = event.getSource().get('v.text');
        var isSelected = event.getSource().get('v.value');
        var wrappers = component.get('v.wrappers');
        for (var i = 0; i < wrappers.length; i++) {
            if(wrappers[i].name === selected) {
                for (var j = 0; j < wrappers[i].views.length; j++) {
                    wrappers[i].views[j].isSelected = isSelected;
                }
                component.set('v.wrappers', wrappers);
                break;
            }
        }
    },

    selectAll : function (component, event, helper) {
        var wrappers = component.get('v.wrappers');
        for (var i = 0; i < wrappers.length; i++) {
            for (var j = 0; j < wrappers[i].views.length; j++) {
                wrappers[i].views[j].isSelected = true;
            }
        }
        component.set('v.wrappers', wrappers);
    },

    deselectAll : function (component, event, helper) {
        var wrappers = component.get('v.wrappers');
        for (var i = 0; i < wrappers.length; i++) {
            for (var j = 0; j < wrappers[i].views.length; j++) {
                wrappers[i].views[j].isSelected = false;
            }
        }
        component.set('v.wrappers', wrappers);
    },
    handleFilesChange : function(component, event, helper){
        var files = event.getSource().get("v.files");
        for (var i = 0; i < files.length; i++) {
            helper.importFile(component, files[i]);
        }
    },

    updateViews : function (component, event, helper) {
        helper.upsertViews(component, event, helper);
    }
})