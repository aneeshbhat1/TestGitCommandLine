({
    doinit:function(component,event,helper)
    {
        //component.set("v.ownerURL", "#/sObject/" + ownerRec.Id + "/view");
    }
})