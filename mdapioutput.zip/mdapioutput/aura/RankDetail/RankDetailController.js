({
	 init: function (cmp, event, helper) {
        debugger;
        helper.fetchparameters(cmp);
    }
})