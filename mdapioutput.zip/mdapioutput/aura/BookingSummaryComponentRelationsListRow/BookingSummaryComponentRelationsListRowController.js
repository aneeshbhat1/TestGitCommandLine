/**
 * Created by britenet-patrykzak on 12/06/2018.
 */
({
    goToObject : function (component, event, helper) {
        var url = '/' + component.get("v.row.Id");
        window.open(url,"_blank");
    }
})