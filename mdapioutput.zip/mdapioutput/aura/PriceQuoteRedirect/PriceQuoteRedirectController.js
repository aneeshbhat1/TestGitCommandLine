({
    doInit: function (component, event, helper) {

        var isConsole;
        var recordId = component.get("v.recordId");
        var action = component.get("c.validateRecordAndOpenPQ");
        action.setParams({ recordId: component.get("v.recordId") });
        action.setCallback(this, function (response) {

            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('inside success');
                var priceQuoteUrl = response.getReturnValue();
                if ($A.util.isEmpty(priceQuoteUrl)) {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title: "Failure!",
                        type: "Error",
                        message: 'PQ Url not configured in Salesforce,Please contact support team !!'
                    });
                    toastEvent.fire();
                }
                else {
                    var workspaceAPI = component.find("workspace");
                    workspaceAPI.isConsoleNavigation().then(function (response) {
                        if (response) {
                            var workspaceAPI = component.find("workspace");
                            workspaceAPI.getFocusedTabInfo().then(function (response) {
                                workspaceAPI.openSubtab({
                                    parentTabId: response.tabId,
                                    url: priceQuoteUrl,
                                    focus: true
                                }).then(function (response) {
                                    workspaceAPI.getTabInfo({
                                        tabId: response
                                    });
                                    workspaceAPI.setTabLabel({
                                        tabId: response,
                                        label: "Price Quote"
                                    });
                                    workspaceAPI.setTabIcon({
                                        tabId: response,
                                        icon: "action:quote",
                                        iconAlt: "Price Quote"
                                    }).then(function (response) {
                                       document.title = "Price Quote | Salesforce";
                                    });
                                });
                            }).catch(function (error) {
                                console.log(response);
                            });
                            var dismissActionPanel = $A.get("e.force:closeQuickAction");
                            dismissActionPanel.fire();
                        }
                        else {
                            var dismissActionPanel = $A.get("e.force:closeQuickAction");
                            dismissActionPanel.fire();
                            window.open(priceQuoteUrl);
                        }
                    })
                        .catch(function (error) {
                            console.log(error);
                        });
                }
            }
            else if (state === "INCOMPLETE") {
                // do something
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title: "Failure!",
                        type: "Error",
                        message: errors[0].message
                    });
                    toastEvent.fire();
                } else {
                    console.log("Unknown error");
                }
            }

        });
        $A.enqueueAction(action);
    }
})