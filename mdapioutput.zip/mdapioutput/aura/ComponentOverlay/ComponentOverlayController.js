({
    handleComponentEvent: function(component, event, helper) {
        let params = event.getParams(),
            config = {}; 

        for (let param in params) {
            config[param] = helper.handleParamAction(component, param, params[param]);
        }
        
        event.stopPropagation();
        component.set('v.config', config);
    }
})