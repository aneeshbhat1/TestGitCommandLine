({
    handleParamAction: function(component, param, value) {
        switch(param) {
            case 'spinnerActive': { 
                return value;
            }
        }
    }
})