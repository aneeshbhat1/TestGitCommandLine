/**
 * Created by arjun.mohan on 8/5/2018.

 */
({
    getLikelyHoodToBook :function (component,event)
    {
        var likelihoodToBookAction = component.get("c.getLikelihoodToBookOptions");
                likelihoodToBookAction.setParams({ recordId: component.get("v.lastactiveOpportunity").Id });
                likelihoodToBookAction.setCallback(this, function(res) {
                    switch (res.getState()) {
                        case "SUCCESS":
                            var likelihoodToBookOptions = JSON.parse(res.getReturnValue());
                            component.set("v.likelihoodToBook", likelihoodToBookOptions);
                            break;
                        case "INCOMPLETE":
                            break;
                        case "ERROR":
                            break;
                    }
                });
                $A.enqueueAction(likelihoodToBookAction);
    },

    getSourceCode :function (component)
        {
              var getSourceId = component.get("c.getExPaxSource");
              getSourceId.setParams({
                                     isHappyCalltask: component.get('v.account').ReadyForHappyCall__c
                                   });
            getSourceId.setCallback(this, function(res) {
                                        switch (res.getState()) {
                                                
                                            case "SUCCESS":
                                                var sourceId = res.getReturnValue();
                                                component.set("v.ExPaxSourceId", sourceId);
                                                break;
                                            case "INCOMPLETE":
                                                break;
                                            case "ERROR":
                                                var errors = res.getError();
                                                var toastEvent = $A.get("e.force:showToast");
                                                toastEvent.setParams({
                                                    "title": "Error",
                                                    "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                                                    "type": "error"
                                                });
                                                console.log(errors[0].message)
                                                toastEvent.fire();
                                                break;
                                        }
                                    });
                                    $A.enqueueAction(getSourceId);
        },

    getExpiryDateForReQualificationTask :function (component)
        {
            var requalificationAction = component.get("c.getExpiryDateForRequalificationCall");
                  
                            requalificationAction.setParams({ recordId: component.get("v.recordId") });
                                    requalificationAction.setCallback(this, function(res) {
                                        switch (res.getState()) {
                                            case "SUCCESS":
                                                var expirydate = res.getReturnValue();
                                                component.set("v.requlificationExpiryDate", expirydate);
                                                break;
                                            case "INCOMPLETE":
                                                break;
                                            case "ERROR":
                                                var errors = res.getError();
                                                var toastEvent = $A.get("e.force:showToast");
                                                toastEvent.setParams({
                                                    "title": "Error",
                                                    "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                                                    "type": "error"
                                                });
                                                console.log(errors[0].message)
                                                toastEvent.fire();
                                                break;
                                        }
                                    });
                                    $A.enqueueAction(requalificationAction);
        },
        showRequiredFields: function(component){
            $A.util.addClass(component.find("requiredProgram"), "customRequired");
            $A.util.addClass(component.find("requiredOffice"), "customRequired");
        },
    	getLatestActiveOpportunity:function(component)
    	{
        var getLastActiveOpportunity = component.get("c.getlastestActiveOpportunity");
        getLastActiveOpportunity.setParams({ recordId: component.get("v.recordId") });
        getLastActiveOpportunity.setCallback(this, function(res) {
            switch (res.getState()) {
                case "SUCCESS":
                var opportunity = res.getReturnValue();
                component.set("v.lastactiveOpportunity", opportunity);
    			component.find("requiredProgram").set("v.value", component.get("v.lastactiveOpportunity").Program__c);
                component.set("v.required1",component.get("v.lastactiveOpportunity").Program__c);
                component.set("v.required2",component.get("v.lastactiveOpportunity").SalesOffice__c);
                 this.getLikelyHoodToBook(component,event);
                    this.getCloseReasons(component);
                break;
                 case "INCOMPLETE":
                  break;
                  case "ERROR":
                  var errors = res.getError();
                    var toastEvent = $A.get("e.force:showToast");
                  toastEvent.setParams({
                      "title": "Error",
                      "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                      "type": "error"
                      });
                      console.log(errors[0].message);
                      toastEvent.fire();
                      break;
                      }
                      });
                      $A.enqueueAction(getLastActiveOpportunity);
    },    
    getCloseReasons :function(component)
    {
         var closeReasonsAction = component.get("c.getCloseReasons");
        var LAC_SELECTED_CLOSEREASON = $A.get("$Label.c.LAC_SELECTED_CLOSEREASON");
        closeReasonsAction.setParams({ recordId: component.get("v.lastactiveOpportunity").Id });
        closeReasonsAction.setCallback(this, function(res) {
            switch (res.getState()) {
                case "SUCCESS":
                    var closeReasonTemp = [];
                    var closeReasons = JSON.parse(res.getReturnValue());
                    component.set("v.closeReasons", closeReasons);
                    component.set("v.closeReasonsall", closeReasons);
                    
                    break;
                case "INCOMPLETE":
                    break;
                case "ERROR":
                    break;
            }
        });
        $A.enqueueAction(closeReasonsAction);
    },
    changeclosereasons:function(component)
    {
        var arrayclose=component.get("v.closeReasons");
        arrayclose.length=0;
       if(component.get("v.selectedActionType")==$A.get("$Label.c.LAC_Call_Not_Reached")) 
       {
          for (var i = 0; i < component.get("v.closeReasonsall").length; i++) { 
              if(component.get("v.closeReasonsall")[i].toUpperCase()==$A.get("$Label.c.NotAbleToContactCustomer").toUpperCase())
              {
                 arrayclose.push(component.get("v.closeReasonsall")[i]);
                 component.set("v.selectedCloseReason", component.get("v.closeReasonsall")[i]); 
                 break;
              }
           }
       }
        else if(component.get("v.selectedActionType")==$A.get("$Label.c.LAC_Call_Reached"))
        {
           for (var i = 0; i < component.get("v.closeReasonsall").length; i++) { 
               arrayclose.push(component.get("v.closeReasonsall")[i]);
           } 
        }
        component.set("v.closeReasons",arrayclose);
    },

    navigateToActionScreen: function(component, event) {
        var navigationItemAPI = component.find("navigationItem");
        var workspaceAPI = component.find("workspace");
        var self = this;

        workspaceAPI.isConsoleNavigation().then(function(response) {

            if(response){
                var currentTabId;
                workspaceAPI.getAllTabInfo().then(function(response) {
                    console.log('ALL TAB INFO ' + Object.entries(response) );
                    var actionScreen = self.actionScreenPageReference(response);
                    if(actionScreen == null){
                        workspaceAPI.getFocusedTabInfo().then(function(response) {
                            var currentTabId = response.tabId;
                            if(response.isSubtab){
                                currentTabId = response.parentTabId;
                            }else{
                                currentTabId = response.tabId;
                            }
                            workspaceAPI.closeTab({tabId: currentTabId}).then(function(response){
                                workspaceAPI.openTab({
                                    url: '/lightning/n/AG_Action_Screen?overrideNavRules=true',
                                    focus : true
                                });
                            });
                        });
                    }else{
                        workspaceAPI.getFocusedTabInfo().then(function(response) {
                            var currentTabId = response.tabId;
                            if(response.isSubtab){
                                currentTabId = response.parentTabId;
                            }else{
                                currentTabId = response.tabId;
                            }
                            workspaceAPI.openTab({
                                pageReference : actionScreen,
                                focus : true
                            }).then(function(response){
                                workspaceAPI.closeTab({tabId: currentTabId}).then(function(response){
                                    workspaceAPI.getFocusedTabInfo().then(function(response){
                                        var focusedTabId = response.tabId;
                                        workspaceAPI.refreshTab({
                                            tabId: focusedTabId,
                                            includeAllSubtabs: true
                                        });
                                    });
                                });
                            });
                        })
                    }
                });
            }else{
                $A.util.addClass(spinner, "slds-hide");
                var urlEvent = $A.get("e.force:navigateToURL");
                var LAC_ActionScreenURL = $A.get("$Label.c.LAC_ActionScreenURL");
                urlEvent.setParams({ url: LAC_ActionScreenURL });
                urlEvent.fire();
            }
        })
        .catch(function(error) {
            console.log(error);
        });
    },

    actionScreenPageReference: function(tabSet){
        var actionScreenAlreadyOpenFlag;
        var actionScreenPageReference;
        tabSet.forEach(function(element) {
            if(Object.keys(element.pageReference.attributes).indexOf('apiName') != -1 &&
                element.pageReference.attributes.apiName == 'AG_Action_Screen'){
                    actionScreenAlreadyOpenFlag = true;
                    actionScreenPageReference= element.pageReference;
            }
        });
        return actionScreenPageReference;
    },

})