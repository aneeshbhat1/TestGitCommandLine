/**
 * Created by britenet-patrykzak on 16/08/2018.
 */
({

    init: function(component, event, helper) {

        var getInitialData = component.get('c.getInitialData');
        getInitialData.setParams({
            "recordId": component.get('v.recordId')
        })
        getInitialData.setCallback(this, $A.getCallback(function(response) {
            var state = response.getState();
            if (state === "SUCCESS" && response.getReturnValue()) {
                var wrapper = response.getReturnValue();
                if(wrapper){
                    component.set('v.opportunities',wrapper.opportunities);
                    component.set('v.leads',wrapper.leads);
                    component.set('v.bookings',wrapper.bookings);
                    helper.calculateMaxYear(component, wrapper.bookings, wrapper.opportunities, wrapper.leads);
                    helper.calculateStats(component, wrapper.bookings, wrapper.opportunities, wrapper.leads);
                }
            } else if (state === "INCOMPLETE") {

            } else if (state === "ERROR") {
                var errors = response.getError();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                   "mode": "dismissible",
                   "title": 'Error',
                   "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                   "type": 'error'
                })
                toastEvent.fire();
            }
        }));
        $A.enqueueAction(getInitialData);
    },

    waiting: function(component, event, helper) {
        component.set("v.HideSpinner", true);
    },

    doneWaiting: function(component, event, helper) {
        component.set("v.HideSpinner", false);
    },
})