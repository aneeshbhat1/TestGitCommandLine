/**
 * Created by britenet-patrykzak on 06/11/2018.
 */
({
    validateRequiredFields :function (component, event){
        var eventFields = event.getParam("fields");
        var requiredFields = {
            'PersonEmail' : 'Email',
            'FirstName' : 'First Name',
            'LastName' : 'Last Name'
        };
        var missingFields = [];
        Object.keys(requiredFields).forEach(function(entryField) {
            if (eventFields[entryField] == '') {
                missingFields.push(requiredFields[entryField]);
            }
        });
        if (missingFields.length > 0){
            event.preventDefault();
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Required fields missing",
                "message": "Please fill " + missingFields.join(', ') + " field",
                "type": "error"
            });
            toastEvent.fire();
        }
    },

})