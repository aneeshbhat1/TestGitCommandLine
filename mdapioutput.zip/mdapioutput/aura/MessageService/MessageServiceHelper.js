({
    handleServerErrors: function(component, params) {
        const errors = params.errors;
        const toastParams = {
            title: 'Server Error'
        };
        let isUnknownError = true;

        if (typeof errors !== 'undefined' && Array.isArray(errors) && errors.length > 0) {
            errors.forEach(error => {
                if (typeof error.message !== 'undefined') {
                toastParams.message = error.message;
                this.showError(component, toastParams);
                isUnknownError = false;
            }
            const pageErrors = error.pageErrors;
            if (typeof pageErrors !== 'undefined' && Array.isArray(pageErrors) && pageErrors.length > 0) {
                pageErrors.forEach(pageError => {
                    if (typeof pageError.message !== 'undefined') {
                    toastParams.message = pageError.message;
                    this.showError(component, toastParams);
                    isUnknownError = false;
                }
            });
            }
        });
        }

        if (isUnknownError) {
            toastParams.message = 'Unknown error';
            this.showError(component, toastParams);
        }

        console.error(JSON.stringify(errors));
    },

    showError: function(component, params) {
        params.title = params.title || component.get('v.defaultErrorMessageHeaderTitle');
        params.variant = 'error';
        params.mode = 'sticky';
        this.showToast(component, params);
    },

    showSuccess: function(component, params) {
        params.title = params.title || component.get('v.defaultSuccessMessageHeaderTitle');
        params.variant = 'success';
        this.showToast(component, params);
    },

    showWarning: function(component, params) {
        params.title = params.title || component.get('v.defaultWarningMessageHeaderTitle');
        params.variant = 'warning';
        params.mode = 'sticky';
        this.showToast(component, params);
    },

    showToast: function(component, params) {
        component.find('notifLib').showToast(params);
    },

    showNotice: function(component, params) {
        component.find('notifLib').showNotice(params);
    }
})