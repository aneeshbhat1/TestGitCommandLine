({
    handleServerErrors: function(component, event, helper) {
        const params = event.getParams().arguments;
        helper.handleServerErrors(component, params);
    },

    showToast: function(component, event, helper) {
        const params = event.getParams().arguments;
        helper.showToast(component, params);
    },

    showError: function(component, event, helper) {
        const params = event.getParams().arguments;
        helper.showError(component, params);
    },

    showSuccess: function(component, event, helper) {
        const params = event.getParams().arguments;
        helper.showSuccess(component, params);
    },

    showWarning: function(component, event, helper) {
        const params = event.getParams().arguments;
        helper.showWarning(component, params);
    },

    showNotice: function(component, event, helper) {
        const params = event.getParams().arguments;
        helper.showNotice(component, params);
    }
})