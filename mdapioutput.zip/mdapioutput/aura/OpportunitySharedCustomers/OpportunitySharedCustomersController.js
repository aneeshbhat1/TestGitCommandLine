/**
 * Created by britenet-patrykzak on 17/09/2018.
 */
({
    init: function(component, event, helper) {

        var getInitialData = component.get("c.getInitialData");
        getInitialData.setParams({ recordId: component.get("v.recordId") });
        getInitialData.setCallback(this, function(res) {
            switch (res.getState()) {
                case "SUCCESS":
                    var data = res.getReturnValue();
                    component.set('v.customerId', data.customerId);
                    component.set('v.shareWithValues', data.availableBusinessUnits);
                    break;
                case "INCOMPLETE":
                    break;
                case "ERROR":
                    var errors = res.getError();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                        "type": "error"
                    });
                    toastEvent.fire();
                    break;
            }
        });
        $A.enqueueAction(getInitialData);
    },

    closeModal : function(component, event, helper){
        $A.get("e.force:closeQuickAction").fire();
    },

    createShareRecord : function(component, event, helper){

        var allValid = component.find('requiredField').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);

        if (allValid) {
            var createRecord = component.get("c.createRecord");
            createRecord.setParams({
                customerId: component.get("v.customerId"),
                sharedWith: component.get("v.shareWithChosenValue"),
                comments: component.get("v.comments")
            });
            createRecord.setCallback(this, function(res) {
                switch (res.getState()) {
                    case "SUCCESS":
                        $A.get("e.force:closeQuickAction").fire();
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                           "message": "The record has been created successfully.",
                           "type": "Success"
                        });
                        toastEvent.fire();
                        $A.get("e.force:refreshView").fire();
                        break;
                    case "INCOMPLETE":
                        break;
                    case "ERROR":
                        var errors = res.getError();
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error",
                            "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                            "type": "error"
                        });
                        toastEvent.fire();
                        break;
                }
            });
            $A.enqueueAction(createRecord);
        }
    },
})