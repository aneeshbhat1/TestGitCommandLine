({
    refreshPage: function(component) {
        $A.get('e.force:refreshView').fire();
    }
})