({
    refreshPage: function(component, event, helper) {
        helper.refreshPage(component);
    },

    navigateToUrl: function(component, event, helper) {
        const params = event.getParams().arguments;

        $A.get('e.force:navigateToURL').setParams({
           'url': params.url
        }).fire();
    },

    navigateToSobject: function(component, event, helper) {
        const params = event.getParams().arguments;

        $A.get('e.force:navigateToSObject').setParams({
            'recordId': params.recordId,
            'slideDevName': params.slideDevName || 'detail'
        }).fire();
    }
})