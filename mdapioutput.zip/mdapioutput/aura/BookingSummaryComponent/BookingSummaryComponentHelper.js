({
	insertRecord: function(cmp, event) {
		var action = cmp.get('c.updateAccountDetails');
		var fwrapperLst = cmp.get('v.wrapperList');
		action.setParams({
			wrapperData: JSON.stringify(fwrapperLst)
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if (state === 'SUCCESS') {
				if (response.getReturnValue() === '') {
					var toastEvent = $A.get('e.force:showToast');
                    var bookingSummarySuccess = $A.get('$Label.c.bookingSummarySuccess');
					toastEvent.setParams({
						title: 'Success!',
						type: 'success',
						message: bookingSummarySuccess,
					});
					toastEvent.fire();
					//Add navigation to detail view here
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url":"/apex/ShowCustomer?id="+cmp.get('v.wrapperList.personAcc.Id')
                    });
                    urlEvent.fire();

					window.setTimeout(
						$A.getCallback(function() {
							var navEvt = $A.get('e.force:navigateToSObject');
							navEvt.setParams({
								recordId: cmp.get('v.wrapperList.opp.Id'),
							});
							navEvt.fire();
						}),
						5000
					);
				} else {
					var toastEvent = $A.get('e.force:showToast');
                    var SaveFailed = $A.get('$Label.c.SaveFailed');
					toastEvent.setParams({
						title: 'Failure!',
						type: "error",
						message: SaveFailed +'-'+response.getReturnValue() ,
					});
					toastEvent.fire();
				}
			} else if (state === 'INCOMPLETE') {
			} else if (state === 'ERROR') {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						var toastEvent = $A.get('e.force:showToast');
                                            var SaveFailed = $A.get('$Label.c.SaveFailed');
                        					toastEvent.setParams({
                        						title: 'Failure!',
                        						type: "error",
                        						message: SaveFailed +' - '+errors[0].message ,
                        						 duration:10000
                        					});
                        					toastEvent.fire();

                                         var navEvt = $A.get('e.force:navigateToSObject');
                   							navEvt.setParams({
                   								recordId: cmp.get('v.wrapperList.personAcc.Id'),
                   							});
                   							navEvt.fire();
					}
				} else {
					console.log('Unknown error');
				}
			}
		});
		$A.enqueueAction(action);
	},
    checkIfHasParents: function(component,event){
        var accountId = component.get("v.wrapperList.personAcc.Id");
        var action = component.get("c.checkIfHasParents");
        action.setParams({
            recordId: accountId
        });

        action.setCallback(this, function(response) {
        var state = response.getState();
            if (state === 'SUCCESS') {
                var data = response.getReturnValue();
                component.set('v.hasParent',data.length>0);
                component.set('v.relations',data);
            }
        })
        $A.enqueueAction(action);
    },

    checkIfUnderagedRequireParent: function(component,event){
        var age = component.get("v.wrapperList.age");
        var program = component.get("v.wrapperList.opp.Program__c");
        var action = component.get("c.checkIfUnderagedRequireParent");
        action.setParams({
            program: program,
            age: age
        });
        action.setCallback(this, function(response) {
            switch (response.getState()){
                case "SUCCESS":
                    component.set('v.familyMemberRequired', response.getReturnValue());
                    break;
                case "ERROR":
                    var errors = res.getError();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "message": errors[0] && errors[0].message ? errors[0].message : 'Unknown error',
                        "type": "error"
                    });
                    toastEvent.fire();
                    break;
            }
        })
        $A.enqueueAction(action);
    },
});