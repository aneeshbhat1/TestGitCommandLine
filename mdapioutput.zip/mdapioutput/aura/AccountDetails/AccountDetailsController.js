({
    updateAccount: function(component, event, helper){
        var tempRec = component.find("accountRecord");
        tempRec.set("v.recordId", component.get("v.Opportunity.AccountId"));
        tempRec.reloadRecord();
    }, 
})