({
	NavigateToQuote : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef: "c:BookingSummaryComponent",
            componentAttributes: {
                RecordId: component.get("v.recordId")
            }
        });
        evt.fire();
    }
})