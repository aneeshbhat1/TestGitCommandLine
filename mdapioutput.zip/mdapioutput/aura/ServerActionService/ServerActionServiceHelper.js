({
    callServer : function(params) {
        const action = params.action;

        if (params.params !== null) {
            action.setParams(params.params);
        }

        action.setCallback(this, response => {
            const state = response.getState();
            if (state === 'SUCCESS') {
                if (params.successCallback) {
                    params.successCallback(response.getReturnValue());
                }
            }
            else if (state === 'ERROR') {
                const errors = response.getError();
                if (params.errorCallback) {
                    params.errorCallback(errors);
                }
            }
        });

        if (params.isStorable) {
            action.setStorable();
        }

        if (params.isBackground) {
            action.setBackground();
        }

        if (params.isAbortable) {
            action.setAbortable();
        }

        $A.enqueueAction(action);
    },

    callServerPromise : function(params) {
        return new Promise((resolve,reject) => {
            const action = params.action;

            if (params.params !== null) {
                action.setParams(params.params);
            }

            action.setCallback(this, response => {
                const state = response.getState();
                if (state === 'SUCCESS') {
                    resolve(response.getReturnValue());
                }
                else if (state === 'ERROR') {
                    const errors = response.getError();
                    reject(errors);
                }
            });

            if (params.isStorable) {
                action.setStorable();
            }

            if (params.isBackground) {
                action.setBackground();
            }

            if (params.isAbortable) {
                action.setAbortable();
            }

            $A.enqueueAction(action);
        });
    }
})