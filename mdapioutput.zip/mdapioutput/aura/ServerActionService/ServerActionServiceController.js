({
    callServer : function(component, event, helper) {
        const params = event.getParam('arguments');
        return helper.callServer(params);
    },

    callServerPromise : function(component, event, helper) {
        const params = event.getParam('arguments');
        return helper.callServerPromise(params);
    }
})