({
    CUSTOM_VALUE : '!@#CuStą#@§@#VaLuĘ#@!',

    loadOptions : function(component) {
        var controllingFieldName = component.get('v.controllingFieldName'),
            isControlled = controllingFieldName != null,
            action = component.get('c.' + (isControlled ? 'getDependentOptions' : 'getPickListValues')),
            params = {objApiName:component.get('v.objectName'), fieldName:component.get('v.fieldName')};

        if (isControlled) {
            params.contrFieldApiName = controllingFieldName;
        }

        action.setParams(params);

        component.set('v.loading', true);
        action.setCallback(this, function (response) {
            component.set('v.loading', false);
            var state = response.getState();
            if (state === 'SUCCESS') {
                this.calculateAvailableOptions(component, response.getReturnValue());
            } else if (state === 'ERROR') {
                var errors = response.getError(),
                    firstError = (errors && errors[0] && errors[0].message) ? errors[0].message : 'Unknown error';
                this.showError('Server Error', firstError);
            }
        });
        $A.enqueueAction(action);
    },

    populateOptions : function(component) {
        var controllingFieldName = component.get('v.controllingFieldName'),
            controllingFieldValue = component.get('v.controllingFieldValue'),
            isControlled = controllingFieldName != null || controllingFieldValue != null,
            hasEmptyVal = component.get('v.addEmptyVal'),
            hasCustomVal = component.get('v.addCustomVal'),
            val = component.get('v.value'),
            availableOptions = component.get('v.availableOptions'), i, hasVal;

        if (isControlled) {
            component.set('v.value', '');
            if (controllingFieldValue && availableOptions && availableOptions[controllingFieldValue]) {
                component.set('v.selectedOptions', availableOptions[controllingFieldValue]);
            } else {
                component.set('v.selectedOptions', []);
            }
        } else {
            component.set('v.selectedOptions', availableOptions);
        }

        if (val) {
            availableOptions = component.get('v.selectedOptions');
            if (availableOptions.length > 0) {
                hasVal = false;
                for (i = 0; i < availableOptions.length; i++) {
                    if (availableOptions[i].value == val) {
                        hasVal = true;
                        break;
                    }
                }

                if (!hasVal) {
                    if (hasCustomVal) {
                        component.set('v.customValSelected', true);
                    } else if (hasEmptyVal) {
                        component.find('picklist').set('v.value', '');
                    } else {
                        component.find('picklist').set('v.value', availableOptions[0].value);
                    }
                }
            }
        }
    },

    calculateAvailableOptions : function(component, options) {
        if (options && options.length > 0 && component.get('v.addCustomVal')) {
            options.push({value:this.CUSTOM_VALUE, label: component.get('v.customValLabel'), customValue:true});
        }
        component.set('v.availableOptions', options);
    },

    initCustomValue : function(component) {
        if (component.get('v.addCustomVal') && component.get('v.controllingFieldHasCustomValue')) {
            component.set('v.customValSelected', true);
            if (component.get('v.value') == this.CUSTOM_VALUE || !this.isCustomValue(component, component.get('v.value'))) {
                component.set('v.value', '');
            }
        }
    },

    findCustomValue: function(component, value) {
        var availableOptions = component.get('v.selectedOptions'), i;
        for (i = 0; i < availableOptions.length; i++) {
            if (availableOptions[i].customValue) {
                return availableOptions[i];
            }
        }
        return null;
    },

    isCustomValue : function(component, value) {
        var availableOptions = component.get('v.selectedOptions'), i;
        for (i = 0; i < availableOptions.length; i++) {
            if (!availableOptions[i].customValue && availableOptions[i].value === value) {
                return false;
            }
        }
        return true;
    },

    showToast : function(type, title, message) {
        var toastEvent = $A.get('e.force:showToast');
        if(toastEvent) {
            toastEvent.setParams({
                'title': title,
                'message': message,
                'type': type,
                'mode': 'sticky'
            });
            toastEvent.fire();
        } else {
            alert(message);
        }
    },

    showError : function(title, message) {
        this.showToast('error', title, message);
    },

    throwEvent: function(component, eventName) {
        var action = component.get('v.' + eventName);

        if (action != null){
            component.set('v.' + eventName + 'Helper', component.get('v.' + eventName + 'Helper') + 1);
        }
    }
})