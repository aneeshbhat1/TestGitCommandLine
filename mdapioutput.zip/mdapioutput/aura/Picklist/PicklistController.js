({
    doInit : function(component, event, helper) {
        var options = component.get('v.options'),
            objApiName = component.get('v.objectName'),
            fieldName = component.get('v.fieldName');

        if (objApiName && fieldName) {
            helper.loadOptions(component);
        } else {
            helper.calculateAvailableOptions(component, options);
        }

        helper.initCustomValue(component);
    },

    onFocus : function(component, event, helper) {
        component.find('picklist').focus();
    },

    onShowHelpMessageIfInvalid : function(component, event, helper) {
        var picklist = component.find('picklist'),
            customValueField = component.find('customValueField'),
            value = component.get('v.value');

        if(!value){
            picklist.showHelpMessageIfInvalid();
        }

        if(!$A.util.isEmpty(customValueField)) {
            customValueField.showHelpMessageIfInvalid();
        }
    },

    refresh : function(component, event, helper) {
        helper.populateOptions(component);
    },


    onInternalChange : function (component, event, helper) {
        var value = component.get('v.value'),
            picklist = component.find('picklist');
        if (component.get('v.addCustomVal') && helper.isCustomValue(component, value)) {
            if ($A.util.isEmpty(value)) {
                component.set('v.customValSelected', false);
                component.set('v.customValueSelectedClass', '');
            } else {
                component.set('v.customValSelected', true);
                component.set('v.customValueSelectedClass', 'customValueSelected');
                component.set('v.value', '');
            }
        } else {
            component.set('v.customValSelected', false);
            component.set('v.customValueSelectedClass', '');
        }
        helper.throwEvent(component, 'onchange');
    },

    onCustomValueChange : function (component, event, helper) {
        helper.throwEvent(component, 'onchange');
    },

    onControllingFieldValueChange : function(component, event, helper) {
        helper.populateOptions(component);
    },

    onControllingFieldHasCustomValueChanged : function(component, event, helper) {
        helper.initCustomValue(component);
    }
})