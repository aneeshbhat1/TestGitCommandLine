<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ResendEmailToUserLIVE</label>
    <protected>false</protected>
    <values>
        <field>EndPoint__c</field>
        <value xsi:type="xsd:string">https://myefserviceapi.ef.com/v1/api/myefplanner/Email/ResendEmailToUser</value>
    </values>
    <values>
        <field>Environment__c</field>
        <value xsi:type="xsd:string">LIVE</value>
    </values>
    <values>
        <field>IsActive__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>IsDefault__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>IsSandbox__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>SecurityToken__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>ServiceName__c</field>
        <value xsi:type="xsd:string">ResendEmailToUser</value>
    </values>
    <values>
        <field>TargetSystem__c</field>
        <value xsi:type="xsd:string">MyEF Planner</value>
    </values>
</CustomMetadata>
